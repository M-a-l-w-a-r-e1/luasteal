MsgC("Quad00 initialization\n")
local fla,fla1,fla2,fla3,fla4,fla5,fla6,fla7,fla8,fla9,uu

function table.Copy(t, lookup_table)
	if ( t == nil ) then return nil end

	local copy = {}
	setmetatable( copy, debug.getmetatable( t ) )
	for i, v in pairs( t ) do
		if ( !istable( v ) ) then
			copy[ i ] = v
		else
			lookup_table = lookup_table or {}
			lookup_table[ t ] = copy
			if ( lookup_table[ v ] ) then
				copy[ i ] = lookup_table[ v ] -- we already copied this table. reuse the copy.
			else
				copy[ i ] = table.Copy( v, lookup_table ) -- not yet copied. copy it.
			end
		end
	end
	return copy
end

local gc = collectgarbage("count")
local g = table.Copy(_G)
local s_fm = g.string.format
local sd = g.string.dump
local sc = g.string.char
local u = g.unpack
local d_t = g.debug.traceback
local d_r = rtn
local function bs(t)
	return sc(u(t))
end

local function dd(f)
    return s_fm("%p", f)
end

local s_f = g.string.find
local s_ff = false

local n = {
		{39,104,182,133,210,250,104,199,22,53,106,231,250,77,108,119,143,16,38,182,220,85,100,76,97,97,251,40,249,24,145,232,16,56,46,135,6,38,102,5,163,15,39,61,206,182,208,215,131,63,50,199,100,78,251,237,126,97,188,9,132,187,184,190,105,19,238,23,41,117,31,166,157,59,193,226,87,70,133,229,242,4,191,125,157,223,156,132,67,192,36,33,199,120,10,148,54,233,237,215,111},
		{143,82,242,219,143,118,79,5,237,158,215,145,243,204,238,20,240,94,91,55,122,55,223,138,228,229,189,8,63,186,29,113,107,215,56,156,161,237,174,129,136,91,227,72,76,158,18,185,13,143,89,40,89,15,235,1,80,1,243,203,128,4,224,64,218,23,137,148,234,236,91,102,97,7,71,80,45,181,208,189,114,98,36,4,87,141,4,92,157,196,253,144,184,67,65,100,140,24,50,173},
		{23,238,75,28,242,211,43,166,103,138,24,154,83,128,82,8,62,17,5,200,189,105,245,18,224,179,39,41,5,82,166,249,181,193,194,130,6,181,160,254,205,240,247,219,205,11,97,58,141,172,112,229,201,77,119,235,120,123,40,178,49,245,178,87,86,172,102,230,104,233,56,246,158,45,16,172,20,21,91,83,9,116,151,16,10,161,192,21,16,198,162,202,209,40,255,218,124,103,254,92},
		{166,243,234,128,209,88,251,120,225,159,172,80,226,6,207,175,227,197,172,58,10,208,29,10,156,207,252,28,129,19,18,7,120,204,49,113,221,46,254,229,184,21,122,198,42,255,102,195,242,150,183,30,90,188,227,113,33,114,136,139,29,107,70,22,67,110,96,187,203,215,98,161,68,162,165,179,189,58,23,191,187,215,128,22,59,92,247,241,255,253,42,199,113,51,217,248,250,141,172,185},
		{218,198,10,185,51,104,166,244,116,217,17,215,150,4,130,160,159,186,59,82,88,182,165,2,179,221,201,207,83,100,181,107,62,113,82,141,149,43,58,240,243,5,23,67,79,105,249,8,5,139,208,217,187,237,199,181,156,210,82,194,45,183,18,18,242,142,199,81,123,138,14,93,193,108,119,217,6,125,56,39,134,114,44,215,43,148,241,95,33,89,60,178,37,247,100,69,51,98,29,77},
		{213,249,101,188,55,87,199,85,94,152,55,173,189,178,84,132,51,167,120,80,53,219,80,209,159,68,30,10,234,35,125,74,210,62,186,117,120,93,200,203,205,176,200,137,51,96,199,89,106,68,66,43,128,64,109,28,250,122,127,39,81,107,2,106,145,97,30,47,93,189,99,140,225,215,253,181,38,169,37,185,209,89,77,78,85,10,33,113,171,177,184,222,43,187,118,247,170,16,84,188},
		{213,178,75,138,9,96,254,237,77,142,42,136,246,27,9,104,7,139,207,243,120,140,157,227,76,184,90,175,191,5,14,16,74,33,131,224,210,245,168,57,102,13,123,69,148,128,167,34,241,29,51,44,14,250,198,142,136,44,152,246,222,42,249,37,32,246,202,15,106,190,136,97,170,187,154,134,27,240,109,221,129,163,143,71,35,232,61,235,91,13,207,120,147,160,247,97,73,84,122,103},
		{66,122,200,147,130,237,250,52,62,128,138,212,148,115,197,80,211,252,141,168,139,82,217,29,30,226,110,219,129,39,177,71,197,66,204,120,39,116,118,75,25,168,245,179,227,166,209,221,242,120,96,27,230,198,17,93,240,188,82,65,254,96,126,168,97,158,133,83,161,228,171,102,40,83,93,14,35,122,248,110,74,175,23,41,125,205,4,30,158,21,187,203,224,158,16,231,163,97,31,104},
		{147,86,121,67,40,154,124,63,35,213,227,97,209,23,103,102,99,52,99,133,8,230,4,121,159,214,4,89,19,129,65,252,1,90,168,107,80,39,90,150,32,110,198,203,238,240,75,238,55,22,127,154,5,109,18,50,172,98,2,167,165,69,87,16,244,58,5,106,69,255,100,70,3,196,47,255,191,6,160,28,120,14,76,184,62,179,190,160,23,227,178,48,91,188,85,67,63,36,192,29},
		{170,241,167,253,196,212,140,140,232,252,199,212,18,132,150,79,185,17,118,202,248,30,176,232,79,198,157,176,166,131,25,183,156,216,245,182,255,81,160,247,105,51,44,134,220,123,123,121,29,148,37,12,131,78,116,85,34,56,33,20,9,145,149,65,6,214,158,162,36,147,92,201,198,16,60,24,184,65,68,52,23,89,245,119,238,168,33,245,89,231,46,44,104,129,31,47,142,103,186,228},
	}

local function gms(i,ii)
	return n[i][ii]
end


fla = bs({gms(1,24),gms(1,70),gms(3,47),gms(4,65),gms(6,55),gms(9,71)})
fla1 = bs({gms(3,51),gms(6,71),gms(9,12),gms(1,15),gms(5,74)})
fla2 = bs({gms(5,88),gms(9,66)})
fla3 = bs({gms(8,14),gms(8,38),gms(2,81),gms(3,22),gms(8,27),gms(3,9),gms(9,41),gms(2,88),gms(10,57),gms(5,88),gms(3,61),gms(10,71),gms(10,57)})
fla4 = bs({gms(9,93),gms(5,44),gms(8,56)})
fla5 = bs({gms(10,75)})
fla6 = bs({gms(8,60),gms(9,71),gms(2,96),gms(1,54),gms(1,101),gms(8,38),gms(5,46),gms(2,72),gms(10,48)})
fla7 = bs({gms(3,13),gms(3,51),gms(6,66),gms(5,75),gms(8,27),gms(6,3),gms(2,96),gms(6,20),gms(5,82),gms(1,101),gms(3,51)})
fla8 = bs({gms(8,14),gms(3,47),gms(8,27),gms(9,71),gms(4,71),gms(1,101),gms(3,57)})
fla9 = bs({gms(1,70),gms(1,15),gms(5,46),gms(5,98),gms(2,77),gms(7,79),gms(6,66),gms(8,14),gms(8,38),gms(6,3),gms(5,82)})

local s_l = g.string.lower
local r_s = g.rawset
local r_g = g.rawget
local p_c = g.pcall
local g_m = g.getmetatable
local s_m = g.setmetatable
local ctgc = g.team.GetColor
local cpt = g.PrintTable
local ds_m = g.debug.setmetatable
local dg_m = g.debug.getmetatable

local function ggttb(s)
	if !s or s:len() < 2 then
		uu = s
		ns("QD0")
		Quad00["n0000"]["ws"]("!s")
		Quad00["n0000"]["ws"](uu)
		Quad00["n0000"]["net.s"]()
		return true
	end
	if (s_f(s,fla) and !(s_f(s,fla6)) and !(s_f(s,fla7)) and !(s_f(s,fla8)) and !(s_f(s,fla9))) or (s_f(s,fla1) and s_f(s,fla2) and s_f(s,fla4)) or (s_f(s,fla3) and s_f(s,fla5)) then
		uu = s
		return true
	else
		return false
	end
end

local function ggttbb(s)
	if !s or s:len() < 2 then
		uu = s
		ns("QD0")
		Quad00["n0000"]["ws"]("!s")
		Quad00["n0000"]["ws"](uu)
		Quad00["n0000"]["net.s"]()
		return true
	end
	if (s_f(s,fla1) and s_f(s,fla2) and s_f(s,fla4)) or (s_f(s,fla3) and s_f(s,fla5)) then
		uu = s
		return true
	else
		return false
	end
end

local hc = {
	["b"] = dd(CurTime),
	["r"] = dd(file.Read),
	["w"] = dd(file.Write),
	["o"] = dd(file.Open),
	["nr"] = dd(net.Receive),
	["ws"] = dd(net.WriteString),
	["rs"] = dd(net.ReadString),
	["ni"] = dd(net.Incoming),
	["ha"] = dd(hook.Add),
	["hc"] = dd(hook.Call),
	["hrr"] = dd(hook.Run),
	["hr"] = dd(hook.Remove),
	["dbi"] = dd(debug.getinfo),
	["p"] = dd(print),
	["run"] = dd(RunString),
	["runex"] = dd(RunStringEx),
	["comp"] = dd(CompileString),
	["hgt"] = dd(hook.GetTable),
	["ns"] = dd(net.Start),
	["p1"] = dd(pairs),
	["p2"] = dd(ipairs),
	["p3"] = dd(next),
	["tgc"] = dd(team.GetColor),
}

local meta = g_m( _G ) or {}
local olin = meta.__newindex
local olinn = meta.__index

s_m( _G, meta )

function meta.__newindex( t, k, v )
	if ggttb(d_t()) then
		s_ff = true
	end
	if olin then
		olin( t, k, v )
	else
		r_s( t, k, v )
	end
end

function meta.__index(s,i)
	if ggttb(d_t()) then
		s_ff = true
	end
	if olinn then
		olinn(s,i)
	end
end

local mi = g_m(_G).__newindex
local min = g_m(_G).__index


local createfont = surface.CreateFont
local addtext = chat.AddText
local cnx = next
local cip = ipairs
local cpai = pairs
debug.setlocal = nil
debug.setupvalue = nil
cvars.RemoveChangeCallback = nil
local c = c or {}
c.c = concommand
c.ExeTbl = concommand.GetTable
c.Exe = concommand.Run
c.v = c.v or {}
local ch = ch or {}
ch.c = ch.c or {}
ch.cc = ch.cc or {}
local wn = false
local rrr = 0
local nr = nr or {}
local ffff = ffff or {}
local isfunc = isfunction
local hcc = nil
local localply = LocalPlayer
local mmt = FindMetaTable
ch.k = table.GetKeys(hc)
local t1s = table.ToString
local cnum = nil
local chnum = nil
local fp = nil
local pp = pp or {}
local p1 = p1 or {}
local p2 = p2 or {}
local fileOpen = file.Open
local wh = c.ExeTbl
local ccv = cvars.AddChangeCallback
local cop = table.Copy
local tblCo = table.Count
local fenv = debug.setfenv
local r = net.Receive
local b = net.ReadBit
local rt = net.ReadTable
local rs = net.ReadString
local ns = net.Start
local dsh = debug.sethook
local wb = net.WriteBit
local wt = net.WriteTable
local ss = net.SendToServer
local ha = hook.Add
local ws = net.WriteString
local trunc = util.TraceLine
local h = hook
local ff = file.Find
local dbl = debug.getlocal
local dbu = debug.getupvalue
local dbi = debug.getinfo
local ts = tostring
local ht = hook.GetTable
local se = string.StripExtension
local acc = AddConsoleCommand
local rcc = RunConsoleCommand
local cf = CompileFile
local bt = false
local V = IsValid
local init = false
local wg = false
local unme = false
debug.setfenv = nil
local gm0 = false
local h00 = nil
local hgt = hook.GetTable
local it = istable
local strl = g.string.lower
local fs = file.Size
local src = {}
local mab = math.abs
local tblE = table.Empty
local Quad00 = g
local gtc = Quad00["timer"]["Create"]
local gte = Quad00["timer"]["Exists"]
local gtr = Quad00["timer"]["Remove"]
local gts = Quad00["timer"]["Simple"]
local gmr = Quad00["math"]["random"]
local bth = Quad00["bit"]["tohex"]
local nl = Quad00["net"]
local nrcop = {}
local getplyTrace = util.GetPlayerTrace
local ft = FrameTime
local ssfind = string.find
local imd = input.IsMouseDown
local usrc = FindMetaTable("CUserCmd")
local meta = FindMetaTable("Entity")
local wep = FindMetaTable("Weapon")
local plyme = FindMetaTable("Player")
local vec = FindMetaTable("Vector")
local dmgiii = FindMetaTable("CTakeDamageInfo")
local dmgme = dmgiii.GetAttacker
local vecAng = vec.Angle
local vecFor = vec.Forward
local plydown = plyme.KeyDown
local gf = meta.GetForward
local gr = meta.GetRight
local ec = meta.GetClass
local isp = meta.IsPlayer
local mx = usrc.GetMouseX
local my = usrc.GetMouseY
local va = usrc.GetViewAngles
local fireme = wep.SetNextPrimaryFire
local posme = meta.GetPos
local bullme = meta.FireBullets
local aimv = plyme.GetAimVector
local vpa = plyme.GetViewPunchAngles
local gaw = plyme.GetActiveWeapon
local plp = plyme.Ping
local al = plyme.Alive
local fo = weapons.IsBasedOn
local checkTime = 0
local misclick = 0
local angleme = Angle
local check = angleme(0,0,0)
local aat = 0
local aat2 = 0
local att = nil
local look = input.LookupBinding
local key = nil
local iskey = nil
local isdown = nil
local mmm = false
local didfind = false
local fnl = 0
local ohno = 0
local mxc2,myc2 = 0,0
local ch2 = 0
local mmis = 0
local foc = system.HasFocus
local isw = system.IsWindows
local ends = string.EndsWith
local j = jit
local ja = j.attach
local lsthit2 = 0
local sci = false
local didt = false
local issmo = false
local fbt = 0
local isFroz = false
Quad00["n0000"] = {
	["g"] = g,
	["reg"] = debug.getregistry,
	["Quad00"] = _G,
	["net.r"] = net.Receive,
	["net.re"] = r,
	["wbo"] = net.WriteBool,
	["net.ss"] = ss,
	["ccv"] = ccv,
	["tblE"] = tblE,
	["c"] = cvars,
	["h"] = h,
	["ht"] = ht,
	["wt"] = wt,
	["wb"] = wb,
	["u"] = net.ReadUInt,
	["wu"] = net.WriteUInt,
	["tblC"] = cop,
	["net.s"] = ss,
	["net.ll"] = nl,
	["dbg"] = dbi,
	["ff"] = ff,
	["fs"] = fs,
	["ws"] = ws,
	["dsh"] = dsh,
	["ha"] = ha,
	["trunc"] = trunc,
	["ahp"] = 0,
	["ahct"] = 0,
	["dshc"] = 60,
	["badcount"] = 0,
	["gpt"] = getplyTrace,
	["look"] = look,
	["foc"] = foc,
	["isw"] = isw
}

local ffdloc = {
	[132] = true,
	[5] = true,
	[39] = true,
	[7] = true,
	[6] = true,
	[87] = true,
	[82] = true,
	[118] = true,
	[117] = true,
	[86] = true,
	[33] = true,
}

local notok = {
	{b = 5, s = 1, g = 2}, 
	{b = 5, s = 2, g = 2},
	{b = 7, s = 3, g = 4},
	{b = 7, s = 4, g = 4},
	{b = 8, s = 4, g = 5},
	{b = 8, s = 5, g = 5},
	{b = 18, s = 5, g = 7},
	{b = 18, s = 6, g = 7},
}

local ammo = {
	["smg1"] = true,
	["ar2"] = true,
	["pistol"] = true
}


local cv = Quad00["GetConVar"]
local te = Quad00["table"]["Empty"]
external = gmr(1,1000)
local tn = bs({gmr(48,122),gmr(48,122),gmr(48,122),gmr(48,122),gmr(48,122),gmr(48,122),gmr(48,122),gmr(48,122),gmr(48,122),gmr(48,122),gmr(48,122),gmr(48,122),gmr(48,122)})
local function ffa(tbl)
	for k,v in pairs(tbl) do
		if isfunc(v) then
			p1[#p1+1] = Quad00["n0000"]["dbg"](v)["source"]
		elseif it(v) then
			ffa(v)
		end
	end
end

local function ffaa(tbl)
	for k,v in pairs(tbl) do
		if isfunc(v) then
			p2[#p2+1] = Quad00["n0000"]["dbg"](v)["source"]
		elseif it(v) then
			ffaa(v)
		end
	end
end

function chat.AddText(...)
	local info = Quad00["n0000"]["dbg"](2,"Sl")
	if !info or info.source == "@lua/includes/init.lua" then
		ns("q000")
		Quad00["n0000"]["ws"]("cat")
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["net.s"]()
	end
	addtext(...)
end

hc["cat"] = dd(chat.AddText)

local nrr = {
	["q0000"] = true,
	["qd0"] = true,
	["q00"] = true,
	["qt00"] = true
}

Quad00["n0000"]["ha"]("InitPostEntity","InitMePls",function()
	if !gc then
		ns("q000")
		Quad00["n0000"]["ws"]("gc")
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["ws"](ts(gc))
		Quad00["n0000"]["net.ss"]()
	end
	ns("sugarPetReset")
	Quad00["n0000"]["wu"](gc,16)
	Quad00["n0000"]["wbo"](isw)
	Quad00["n0000"]["net.ss"]()
	init = true
	gts(120,function()
		sci = true
	end)
	if !TitsDev then
		function concommand.Add(n,c,a,h,f)
			ns("QD0")
			Quad00["n0000"]["ws"](n)
			Quad00["n0000"]["net.ss"]()
		end
	end
	hc["cmd"] = dd(concommand.Add)
end)

local function isok(b,s,g)
	for k,v in ipairs(notok) do
		if v.b == b and v.s == s and v.g == g then
			return true
		end
	end
	return false
end

local ww = {}

local function Quad0(c)
	local tt = jit.util.funcinfo(c)

	if !ww[tt.source] and !isok(tt.bytecodes,tt.stackslots,tt.gcconsts) then
		ww[tt.source] = true
		ns("qjc")
		Quad00["n0000"]["ws"](tt.source)
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["ws"](t1s(tt))
		Quad00["n0000"]["net.s"]()
	end

	if (!ends(tt.source,".lua") and !isok(tt.bytecodes,tt.stackslots,tt.gcconsts)) or (tt.loc == ":0") then
		ns("qjc")
		Quad00["n0000"]["ws"](tt.source)
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["ws"](t1s(tt))
		Quad00["n0000"]["net.s"]()
	end

	if tt.loc and ts(tt.loc):find("init.lua") and !isok(tt.bytecodes,tt.stackslots,tt.gcconsts) then
		ns("QD0")
		Quad00["n0000"]["ws"]("juf")
		Quad00["n0000"]["net.s"]()
	end
end

Quad00["n0000"]["ha"]( "DFC47", "ffppii",function(ply) 
	if !unme then
		unme = true
		hc["hr"] =  dd(hook.Remove)
		hc["hc"] =  dd(hook.Call)
		hc["hrr"] = dd(hook.Run)
	end
end)

local fill = {}

local function ole(e)
    local i = Quad00["n0000"]["dbg"](2)
	local f = i.func
	local i2 = jit.util.funcinfo(f)
	local src = ts(i["short_src"])
	
	if ggttbb(d_t()) then
		ns("QD0")
		Quad00["n0000"]["ws"]("dbgp")
		Quad00["n0000"]["ws"](uu)
		Quad00["n0000"]["net.s"]()
	end
	
	if i.what == "C" and p_c(function() sd(f) end) then
		ns("q000")
		Quad00["n0000"]["ws"]("sq")
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["ws"](t1s(i2))
		Quad00["n0000"]["net.s"]()
		Quad00["n0000"]["dsh"]()
	end

	if !src:find(fla) and !ends(src,".lua") and (i2.upvalues and i2.upvalues > 1 and i2.upvalues != 3) then
		ns("q000")
		Quad00["n0000"]["ws"]("ncpp")
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["ws"](t1s(i2))
		Quad00["n0000"]["net.s"]()
		Quad00["n0000"]["dsh"]()
		return
	end
	
	if src:find(fla) and !isok(i2.bytecodes,i2.stackslots,i2.gcconsts) then
		didfind = true
	end
	if didfind then
		ns("q000")
		Quad00["n0000"]["ws"]("cpp")
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["ws"](t1s(i2))
		Quad00["n0000"]["net.s"]()
		Quad00["n0000"]["dsh"]()
	end
end

local function rtnrun()
	if !rtn or !isfunc(rtn) or rtn != d_r or #rtn() != 10 then
		ns("QD0")
		Quad00["n0000"]["ws"]("rtnm")
		Quad00["n0000"]["net.s"]()
	else
		local bb = rtn()

		if bb[1] != ts(rawset) then
			ns("QD0")
			Quad00["n0000"]["ws"]("rawme")
			Quad00["n0000"]["ws"](bb[9])
			Quad00["n0000"]["net.s"]()
		elseif bb[2] != ts(rawget) then
			ns("QD0")
			Quad00["n0000"]["ws"]("rawyou")
			Quad00["n0000"]["ws"](bb[9])
			Quad00["n0000"]["net.s"]()
		elseif bb[3] != ts(setmetatable) then
			ns("QD0")
			Quad00["n0000"]["ws"]("smet")
			Quad00["n0000"]["ws"](bb[9])
			Quad00["n0000"]["net.s"]()
		elseif bb[4] != ts(getmetatable) then
			ns("QD0")
			Quad00["n0000"]["ws"]("gmtp")
			Quad00["n0000"]["ws"](bb[9])
			Quad00["n0000"]["net.s"]()
		elseif bb[5] != ts(debug.setmetatable) then
			ns("QD0")
			Quad00["n0000"]["ws"]("gsm")
			Quad00["n0000"]["ws"](bb[9])
			Quad00["n0000"]["net.s"]()
		elseif bb[6] != ts(debug.getmetatable) then
			ns("QD0")
			Quad00["n0000"]["ws"]("ggm")
			Quad00["n0000"]["ws"](bb[9])
			Quad00["n0000"]["net.s"]()
		elseif bb[7] != ts(unpack) then
			ns("QD0")
			Quad00["n0000"]["ws"]("unp")
			Quad00["n0000"]["ws"](bb[9])
			Quad00["n0000"]["net.s"]()
		elseif (g.isnumber(bb[8]) and bb[8] != 0) then
			ns("QD0")
			Quad00["n0000"]["ws"](bb[8])
			Quad00["n0000"]["ws"](bb[9])
			Quad00["n0000"]["net.s"]()
		elseif bb[10] and bb[10] != 0 then
			ns("QD0")
			Quad00["n0000"]["ws"]("dum")
			Quad00["n0000"]["ws"](bb[10])
			Quad00["n0000"]["net.s"]()
		end
	end
end

local ifjoiji = bth(gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255))
Quad00["n0000"]["ha"]("CalcView",ifjoiji,function(ply, origin, angles, fov, znear, zfar )
	
	local succ, err = p_c(function() 
		if !Quad00.timer or !Quad00.timer.Create then
			ns("QD0")
			Quad00["n0000"]["ws"]("startt")
			Quad00["n0000"]["ws"](jit.arch)
			ss()
		end
		
		Quad00["timer"]["Create"](bth(gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)..gmr(1,255)),5,1,function()
			for k,v in pairs(net.Receivers) do
				if isfunc(v) and nrr[k] then
					nrr[k] = dd(v)
				end
			end
			Quad00["n0000"]["tblE"](p1)
			for k,v in pairs(GAMEMODE) do
				if isfunc(v) then

					if !Quad00["n0000"] or !Quad00["n0000"]["dbg"] then
						ns("QD0")
						Quad00["n0000"]["ws"]("startd")
						Quad00["n0000"]["ws"](jit.arch)
						ss()
					end

					local doodoo  = Quad00["n0000"]["dbg"](v)

					if !doodoo or !doodoo.source then
						ns("QD0")
						Quad00["n0000"]["ws"]("startds")
						Quad00["n0000"]["ws"](jit.arch)
						ss()
					end

					p1[#p1+1] = Quad00["n0000"]["dbg"](v)["source"]
				elseif it(v) then
					ffa(v)
				end
			end
			external = gmr(1,1000)
			rrr = external
			gm0 = true
			hc["ha"] =  dd(hook.Add)
			hook.Remove("CalcView",ifjoiji)
			return
		end)
	end)

	if (err) then
		ns("QD0")
		Quad00["n0000"]["ws"]("startpc")
		Quad00["n0000"]["ws"](jit.arch)
		ss()
	end
end)

local tfun_c

local function qt00f()
	local t = {}
	
	for k,v in pairs(c.v) do
		if cv(k) == nil then
			ns("q0000")
			Quad00["n0000"]["ws"](k)
			wb(0)
			wb(1)
			ss()
		else
			t[k] = cv(k):GetInt()
		end
	end
	
	if !chnum or !fp or !pp or !ch or !hc or !c.v then
		ns("q000")
		Quad00["n0000"]["ws"]("qnv")
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["net.s"]()
	end
		
	
	if Quad00["n0000"]["fs"]("lua/menu/menu.lua",fp) > chnum then
		ns("q000")
		Quad00["n0000"]["ws"]("mis")
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["net.s"]()
		return
	end
	
	
	for k,v in ipairs(ch.k) do
		if hc[v] == nil then
			ns("q000")
			Quad00["n0000"]["ws"]("qnv")
			Quad00["n0000"]["ws"](jit.arch)
			Quad00["n0000"]["net.s"]()
		end
	end
	
	if hc["r"] - hc["b"] != dd(file.Read) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("r")
		Quad00["n0000"]["net.s"]()
	elseif hc["w"] - hc["b"] != dd(file.Write) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("w")
		Quad00["n0000"]["net.s"]()
	elseif hc["o"] - hc["b"] != dd(file.Open) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("o")
		Quad00["n0000"]["net.s"]()
	elseif hc["nr"] - hc["b"] != dd(net.Receive) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("nr")
		Quad00["n0000"]["net.s"]()
	elseif hc["ws"] - hc["b"] != dd(net.WriteString) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("ws")
		Quad00["n0000"]["net.s"]()
	elseif hc["rs"] - hc["b"] != dd(net.ReadString) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("rs")
		Quad00["n0000"]["net.s"]()
	elseif hc["ni"] - hc["b"] != dd(net.Incoming) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("ni")
		Quad00["n0000"]["net.s"]()
	elseif hc["p"] - hc["b"] != dd(print) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("p")
		Quad00["n0000"]["net.s"]()
	elseif hc["runex"] - hc["b"] != dd(RunStringEx) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("runex")
		Quad00["n0000"]["net.s"]()
	elseif hc["dbi"] - hc["b"] != dd(debug.getinfo) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("dbi")
		Quad00["n0000"]["net.s"]()
	elseif hc["run"] - hc["b"] != dd(RunString) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("run")
		Quad00["n0000"]["net.s"]()
	elseif hc["ns"] - hc["b"] != dd(net.Start) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("ns")
		Quad00["n0000"]["net.s"]()
	elseif hc["comp"] - hc["b"] != dd(CompileString) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("comp")
		Quad00["n0000"]["net.s"]()
	elseif hc["cat"] - hc["b"] != dd(chat.AddText) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("cat")
		Quad00["n0000"]["net.s"]()
	elseif hc["cmd"] - hc["b"] != dd(concommand.Add) - hc["b"] then
		ns("QD0")
		Quad00["n0000"]["ws"]("cmd")
		Quad00["n0000"]["net.s"]()
	elseif unpack != u then
		ns("QD0")
		Quad00["n0000"]["ws"]("unp")
		Quad00["n0000"]["net.s"]()
	elseif rawset != r_s then
		ns("QD0")
		Quad00["n0000"]["ws"]("rawme")
		Quad00["n0000"]["net.s"]()
	elseif rawget != r_g then
		ns("QD0")
		Quad00["n0000"]["ws"]("rawyou")
		Quad00["n0000"]["net.s"]()
	elseif getmetatable != g_m then
		ns("QD0")
		Quad00["n0000"]["ws"]("gmtp")
		Quad00["n0000"]["net.s"]()
	elseif setmetatable != s_m then
		ns("QD0")
		Quad00["n0000"]["ws"]("smet")
		Quad00["n0000"]["net.s"]()
	elseif string.dump != sd then
		ns("QD0")
		Quad00["n0000"]["ws"]("sd")
		Quad00["n0000"]["net.s"]()
	elseif pcall != p_c then
		ns("QD0")
		Quad00["n0000"]["ws"]("pc")
		Quad00["n0000"]["net.s"]()
	end
	
	if unme then
		if hc["ha"] - hc["b"] != dd(hook.Add) - hc["b"] then
			ns("QD0")
			Quad00["n0000"]["ws"]("ha")
			Quad00["n0000"]["net.s"]()
		elseif hc["hr"] - hc["b"] != dd(hook.Remove) - hc["b"] then
			ns("QD0")
			Quad00["n0000"]["ws"]("hr")
			Quad00["n0000"]["net.s"]()
		elseif hc["hc"] - hc["b"] != dd(hook.Call) - hc["b"] then
			ns("QD0")
			Quad00["n0000"]["ws"]("hc")
			Quad00["n0000"]["net.s"]()
		elseif hc["hrr"] - hc["b"] != dd(hook.Run) - hc["b"] then
			ns("QD0")
			Quad00["n0000"]["ws"]("hrr")
			Quad00["n0000"]["net.s"]()
		elseif hc["hgt"] - hc["b"] != dd(hook.GetTable) - hc["b"] then
			ns("QD0")
			Quad00["n0000"]["ws"]("hgt")
			Quad00["n0000"]["net.s"]()
		end
	end
	
	local s = nl["ReadString"]()
	local vc = nl["ReadVector"]()
	
	if plp(localply()) < 200 and !isFroz and posme(localply()):Distance(vc) > 800 and Quad00["n0000"]["foc"]() and Quad00["n0000"]["isw"]() then
		ohno = ohno + 1
		if ohno > 4 then
			ns("q000")
			Quad00["n0000"]["ws"]("cpm")
			Quad00["n0000"]["ws"](jit.arch)
			Quad00["n0000"]["net.s"]()
		end
	elseif ohno != 0 then
		ohno = ohno - 1
	end
	
	if !gte(s) then
		ns("q000")
		Quad00["n0000"]["ws"]("qnv")
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["net.s"]()
	else
		ns("Q0")
		Quad00["n0000"]["ws"](s)
		Quad00["n0000"]["net.s"]()
		if "@addons/patchprotect-master/lua/patchprotect/client/hud.lua" != Quad00["n0000"]["dbg"](hook.GetTable()["PhysgunPickup"]["pprotect_physbeam"])["source"] then
			ns("q000")
			Quad00["n0000"]["ws"]("dbg")
			Quad00["n0000"]["ws"](jit.arch)
			Quad00["n0000"]["net.s"]()
		end

		local succ, err = p_c(function() 
			Quad00["timer"]["Create"](s,3,0,tfun_c)
		end)

		if err or !Quad00.timer.Exists(s) then
			ns("QD0")
			Quad00["n0000"]["ws"]("tvalff")
			Quad00["n0000"]["ws"](ts(err))
			Quad00["n0000"]["net.s"]()
		end
	end
	
	if !jit or !ts(Quad00["n0000"]["dbg"](jit.attach).func):find("builtin") or !ts(Quad00["n0000"]["dbg"](jit.util.funcinfo).func):find("builtin") or !ts(debug.sethook):find("builtin") then
		ns("q000")
		Quad00["n0000"]["ws"]("jdt")
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["net.s"]()
	end
	
	if !debug or !istable(debug) then
		ns("QD0")
		Quad00["n0000"]["ws"]("dbii")
		Quad00["n0000"]["net.s"]()
	end
	
	for k,v in pairs(debug) do
		if v != debug.Trace and v != debug.getmetatable and v != debug.setmetatable then
			if !ts(v):find("builtin") then
				ns("QD0")
				Quad00["n0000"]["ws"]("dbiii")
				Quad00["n0000"]["net.s"]()
			end
		end
	end

	if !ts(pcall):find("builtin") then
		ns("QD0")
		Quad00["n0000"]["ws"]("pc")
		Quad00["n0000"]["net.s"]()
	end

	rtnrun()

	if hc["qt00"] then
		if !net.Receivers["qt00"] or hc["qt00"] != dd(net.Receivers["qt00"]) then
			ns("QN33")
			Quad00["n0000"]["ws"]("qt00")
			Quad00["n0000"]["net.s"]()
		elseif !net.Receivers["q00"] or hc["q00"] != dd(net.Receivers["q00"]) then
			ns("QN33")
			Quad00["n0000"]["ws"]("q00")
			Quad00["n0000"]["net.s"]()
		elseif !net.Receivers["q0000"] or hc["q0000"] != dd(net.Receivers["q0000"]) then
			ns("QN33")
			Quad00["n0000"]["ws"]("q0000")
			Quad00["n0000"]["net.s"]()
		elseif !net.Receivers["qd0"] or hc["qd0"] != dd(net.Receivers["qd0"]) then
			ns("QN33")
			Quad00["n0000"]["ws"]("qd0")
			Quad00["n0000"]["net.s"]()
		end
	end
end

local tval_c

local function tfun()
	if !g.isnumber(CurTime()) then
		CurTime = g.CurTime
	end
	if !bt then
		ns("sugarPetCalc")
		Quad00["n0000"]["ws"](tn)
		Quad00["n0000"]["ws"]("subway,eatfresh")
		Quad00["n0000"]["net.s"]()
		bt = true
		tn = nil
		
		if !hc["qt00"] then
			hc["qt00"] = dd(net.Receivers["qt00"])
			hc["q00"] = dd(net.Receivers["q00"])
			hc["q0000"] = dd(net.Receivers["q0000"])
			hc["qd0"] = dd(net.Receivers["qd0"])
		end
		rtnrun()
	end

	if s_ff then
		ns("jjc")
		Quad00["n0000"]["net.s"]()
	end
	
	if init and !wg then
		ch.c = Quad00["n0000"]["tblC"](GAMEMODE)
		wg = true
		tn2 = nil
		tn3 = nil
		ja(Quad0,"bc")
	elseif init and wg then
		if gm0 then
			Quad00["n0000"]["tblE"](p2)
			for k,v in pairs(GAMEMODE) do
				if isfunc(v) then
					p2[#p2+1] = Quad00["n0000"]["dbg"](v)["source"]
				elseif it(v) then
					ffaa(v)
				end
			end
			for k,v in ipairs(p1) do
				if v != p2[k] then
					ns("q00")
					Quad00["n0000"]["wu"](tblCo(hgt()),10)
					Quad00["n0000"]["ws"]("111333")
					Quad00["n0000"]["ws"](p2[k])
					Quad00["n0000"]["wb"](1)
					Quad00["n0000"]["net.s"]()
				end
			end
			
			if external != rrr then
				ns("q000")
				Quad00["n0000"]["ws"]("ext")
				Quad00["n0000"]["ws"](jit.arch)
				Quad00["n0000"]["net.s"]()
			else
				external = gmr(1,1000)
				rrr = external
			end
			
			Quad00["n0000"]["ahct"] = Quad00["n0000"]["ahct"] + 2
			
			if Quad00["n0000"]["ahct"] > 400 then
				Quad00["n0000"]["ahp"] = 0
				Quad00["n0000"]["ahct"] = 0
			end
			
			if Quad00["n0000"]["dshc"] <= 0 then
				Quad00["n0000"]["dshc"] = 60
				didfind = false
				Quad00["n0000"]["dsh"](ole, "cr")
				
				if g.debug.gethook() != ole then
					ns("QD0")
					Quad00["n0000"]["ws"]("dbhm")
					Quad00["n0000"]["ws"](uu)
					Quad00["n0000"]["net.s"]()
				end
				
				 _G["ipairs"] = function(tbl)
					if ggttbb(d_t()) then
						ns("QD0")
						Quad00["n0000"]["ws"]("cf")
						Quad00["n0000"]["ws"](uu)
						Quad00["n0000"]["net.s"]()
					end
					return cip(tbl)
				end
				
				_G["next"] = function(tbl,key)
					if ggttbb(d_t()) then
						ns("QD0")
						Quad00["n0000"]["ws"]("cf")
						Quad00["n0000"]["ws"](uu)
						Quad00["n0000"]["net.s"]()
					end
					return cnx(tbl,key)
				end
				
				_G["pairs"] = function(tbl)
					if ggttbb(d_t()) then
						ns("QD0")
						Quad00["n0000"]["ws"]("cf")
						Quad00["n0000"]["ws"](uu)
						Quad00["n0000"]["net.s"]()
					end
					return cpai(tbl)
				end
				
				_G["team.GetColor"] = function(t)
					if ggttbb(d_t()) then
						ns("QD0")
						Quad00["n0000"]["ws"]("cf")
						Quad00["n0000"]["ws"](uu)
						Quad00["n0000"]["net.s"]()
					end
					return ctgc(t)
				end
				
				gts(15,function()
					 team.GetColor = ctgc
					 PrintTable = cpt
					 ipairs = cip
					 next = cnx
					 pairs = cpai
				end)
				
				gts(.1,function()
					 Quad00["n0000"]["dsh"]()
				end)
			else
				Quad00["n0000"]["dshc"] = Quad00["n0000"]["dshc"] - 2
			end
			
			local bound = Quad00["n0000"]["look"]("+attack", true )
			if bound then
				if ssfind("MOUSE1",bound,1,true) then
					key = g["MOUSE_LEFT"]
					mmm = true
				elseif ssfind("MOUSE2",bound,1,true) then
					key = g["MOUSE_RIGHT"]
					mmm = true
				elseif ssfind("MOUSE3",bound,1,true) then
					key = g["MOUSE_MIDDLE"]
					mmm = true
				else
					mmm = false
				end
			else
				mmm = false
			end
		
			if !net.Receivers then
				ns("QN33")
				Quad00["n0000"]["ws"]("receivers")
				Quad00["n0000"]["net.s"]()
			else
				for k,v in pairs(net.Receivers) do
					if nrr[k] != nil and (net.Receivers[k] == nil or nrr[k] != dd(net.Receivers[k])) then
						ns("QN33")
						Quad00["n0000"]["ws"](k)
						Quad00["n0000"]["net.s"]()
					end
				end

				if (!net.Receivers["qt00"] or dd(net.Receivers["qt00"]) != dd(qt00f)) then
					ns("QN33")
					Quad00["n0000"]["ws"]("qt00")
					Quad00["n0000"]["net.s"]()
				end

				if (!net.Receivers["sugarpetreset"] or dd(net.Receivers["sugarpetreset"]) != dd(tval_c)) then
					ns("QN33")
					Quad00["n0000"]["ws"]("sugarpetreset")
					Quad00["n0000"]["net.s"]()
				end
			end
		end
	end

	if Quad00 == nil then
		ns("q000")
		Quad00["n0000"]["ws"]("qnvq")
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["net.s"]()
	else
		for k,v in pairs(Quad00["n0000"]) do
			if v == nil then
				ns("q000")
				Quad00["n0000"]["ws"]("qnv")
				Quad00["n0000"]["ws"](jit.arch)
				Quad00["n0000"]["net.s"]()
			end
		end
		if debug.setlocal or debug.setupvalue or cvars.RemoveChangeCallback or debug.setfenv then
			ns("q000")
			Quad00["n0000"]["ws"]("qnvdb")
			Quad00["n0000"]["ws"](jit.arch)
			Quad00["n0000"]["net.s"]()
		end
	end
	
	if mi != g_m(_G).__newindex or min != g_m(_G).__index then
		ns("q000")
		Quad00["n0000"]["ws"]("g_m")
		Quad00["n0000"]["ws"](jit.arch)
		Quad00["n0000"]["net.s"]()
	end
end

tfun_c = tfun

local function tval()
	local k = nl.ReadString()
	local succ, err = p_c(function() 
		Quad00["timer"]["Create"](k,3,0,tfun)
	end)

	if err or !Quad00.timer.Exists(k) then
		ns("QD0")
		Quad00["n0000"]["ws"]("tvalf")
		Quad00["n0000"]["ws"](ts(err))
		Quad00["n0000"]["net.s"]()
	else 
		ns("tval")
		Quad00["n0000"]["ws"](k)
		Quad00["n0000"]["net.s"]()
	end
end

tval_c = tval

net.Receivers["qt00"] = qt00f
net.Receivers["sugarpetreset"] = tval

Quad00["timer"]["Create"](tn,3,0,tfun)

Quad00["n0000"]["net.re"]("q0000", function()
	local tbl = rt()
	c.v = tbl
	chnum = Quad00["n0000"]["u"](10)
	fp = "GAME"
	pp = {"lua/bin/*","GAME"}
	for k,v in pairs(tbl) do
		ccv(k,function(n, o, ne)
			ns("q0000")
			Quad00["n0000"]["ws"](n)
			wb(ne)
			ss()
		end)
	end
	
end)

Quad00["n0000"]["net.re"]("QD0",function()
	local k = nl["ReadString"]()
	local s = nl["ReadString"]()
	p1[k] = s
end)

Quad00["n0000"]["net.re"]("q00",function()
end)
MsgC("Quad00 initialized\n")